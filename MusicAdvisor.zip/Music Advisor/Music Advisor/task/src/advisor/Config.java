package advisor;

public class Config {
    public static String SERVER_PATH = "https://accounts.spotify.com";
    public static String API_PATH = "https://api.spotify.com";

    public static String RETURN_URI = "http://localhost:8080";
    public static String CLIENT_ID = "1461161e8e2448ef978fbdb0eb88772f";
    public static String CLIENT_SECRET = "0b4901d939904be7a2d60ca7793b7fdc";

    public static String ACCESS_TOKEN = "";
    public static String AUTH_CODE = "";
    public static int PAGE_SIZE = 5;

    String test = "The compiler\n" +
            "              cannot handle\n" +
            "              the truth";
}
