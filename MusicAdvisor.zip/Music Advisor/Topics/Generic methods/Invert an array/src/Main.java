import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Function;
import java.util.Collections;

class ArrayUtils {
    public static <T> T[] invert(T[] t) {
        Collections.reverse(Arrays.asList(t));
        return t;
    }
}
